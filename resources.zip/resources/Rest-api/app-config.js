const authCookieName = 'auth-cookie';

module.exports = {
    authCookieName,
}