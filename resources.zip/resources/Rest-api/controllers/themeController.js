const { themeModel } = require("../models");
const { userModel } = require("../models");
const { newPost } = require("./postController");

function getThemes(req, res, next) {
    themeModel
        .find()
        .populate("userId")
        .then((themes) => res.json(themes))
        .catch(next);
}

function getTheme(req, res, next) {
    const { themeId } = req.params;

    themeModel
        .findById(themeId)
        .populate({
            path: "posts",
            populate: {
                path: "userId",
            },
            path: "userId"
        })
        .then((theme) => res.json(theme))
        .catch(next);
}

function createTheme(req, res, next) {
    const { projectName, technology, description, imageUrl, videoUrl, gitHubRepo } = req.body;
    const { _id: userId } = req.user;

    themeModel
        .create({
            projectName,
            technology,
            description,
            imageUrl,
            videoUrl,
            gitHubRepo,
            userId,
            subscribers: [],
            posts: [],
        })
        .then((theme) => res.json(theme))
        .catch(next);
}

function subscribe(req, res, next) {
    const themeId = req.params.themeId;
    const { _id: userId } = req.user;
    themeModel
        .findByIdAndUpdate(
            { _id: themeId },
            { $addToSet: { subscribers: userId } },
            { new: true }
        )
        .then((updatedTheme) => {
            res.status(200).json(updatedTheme);
        })
        .catch(next);
}

function editTheme(req, res, next) {
    const { projectName, technology, description, imageUrl, videoUrl, gitHubRepo } = req.body;
    const { themeId } = req.params;
    const { _id: userId } = req.user;

    themeModel.findOneAndUpdate({ _id: themeId, userId }, { projectName, technology, description, imageUrl, videoUrl, gitHubRepo }, { new: true })
        .then(updatedProject => {
            if (updatedProject) {
                res.status(200).json(updatedProject);
            }
            else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

function deleteTheme(req, res, next) {
    const { themeId } = req.params;
    const { _id: userId } = req.user;

    Promise.all([
        themeModel.findOneAndDelete({ _id: themeId }),
        userModel.findOneAndUpdate({ _id: userId }, { $pull: { themes: themeId } }),
    ])
        .then(([deletedOne, _]) => {
            if (deletedOne) {
                res.status(200).json(deletedOne)
            } else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

module.exports = {
    getThemes,
    createTheme,
    getTheme,
    subscribe,
    editTheme,
    deleteTheme
};
